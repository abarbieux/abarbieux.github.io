#include <kilolib.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h> /* memset */
#include <assert.h>

//state value
#define VIDE 0 // set_color (RGB(0,0,0));
#define METEORE 1 // set_color (RGB(2,1,0));
#define LASER 2 // set_color (RGB(3,3,0));
#define SHIP 3 // set_color (RGB(0,0,3));
#define EXPLOSION 4 // set_color (RGB(3,0,0));
#define GAME_OVER 5 // set_color (RGB(3,3,3));

//type value
#define GENERATOR 0
#define PAIR 1
#define ODD 2
#define BASE 3
#define BASE_CENTER 4


//ship movement
#define STOP 0
#define RIGHT 1
#define LEFT 2

#define FALSE 0
#define TRUE 1




int id;
int state;
int state_send;
int type;
int randomizer;
int distance_ship;
int distance_left_ref;
int distance_left_ref_block;
int neighbor_array [2];
int limit;
int ship_movement;

message_t message;
distance_measurement_t dist;







void setup() {


	//set the state
	state = VIDE;
	state_send = VIDE;
	id = kilo_uid;
	type = BASE;
	distance_ship = 0;
	distance_left_ref = 0;
	ship_movement = 5;


	//set the message to send
	message.type = NORMAL;
	message.data[0] = state_send;
	message.data[1] = id;
	message.data[2] = type;
	message.data[3] =  distance_ship;
	message.data[4] =  distance_left_ref;
	message.data[5] =  ship_movement;
	message.crc = message_crc(&message);

	//set the light
	set_color (RGB(0,0,0));



}

void loop() {
	if ( state == GAME_OVER){
		//game over
		set_color (RGB(3,3,3));
	}
	 if((kilo_ticks %64) == 0){ // start loop every 2 sec
	 	ship_movement = 5;
		if ( state == SHIP) {
			//choice the movement of the ship
			randomizer = rand_hard() %2;
			//ship stop
			if (randomizer == 0){
				 state = SHIP;
				 set_color (RGB(0,0,3));
				 state_send = SHIP;
 				 ship_movement = STOP;

			 }
			 //ship go left
			 else if (randomizer == 1){
				 state = VIDE;
			 	 set_color (RGB(0,0,3));
			 	 state_send = SHIP;
				 ship_movement = LEFT;

				 
			 }
		 }//set state to GAME_OVER
		 else if (state == METEORE){
			 state = GAME_OVER;
			 set_color (RGB(2,1,0));
			 state_send = GAME_OVER;
		 }//set state to VIDE
		 else if ( state == VIDE){
			 state_send = VIDE;
			 set_color (RGB(0,0,0));
		 }//reset state when explosion
		 else if ( state == EXPLOSION){
				state_send = VIDE;
				set_color (RGB(3,0,0));
		 }
		 //clear neighbor_array
		 memset(neighbor_array,0,2 * sizeof(int));

	 }
}


//send a message
message_t* message_tx(){
	message.type = NORMAL;
	message.data[0] = state_send;
	message.data[1] = id;
	message.data[2] = type;
	message.data[3] =  distance_ship;
	message.data[4] =  distance_left_ref;
	message.data[5] =  ship_movement;
	message.crc = message_crc(&message);
	return &message;
}
// check a message
void message_rx(message_t *msg, distance_measurement_t *dist) {
	if (msg->data[0] == GAME_OVER){
		//stop the game if GAME_OVER
		state = GAME_OVER;
	}
	
	int i;
	for ( i = 0; i<2; i++) {
		assert(i<2);
		//avoid that a cell could be count more than one time
		if(msg->data[1] == neighbor_array[i]){
			//stop loop if message already receive
			break;
		}
		
		//Find the distance from Base_left_ref
		if (distance_left_ref_block == FALSE){
			if ( msg->data[4] != 0 && msg->data[2] == BASE ){
				distance_left_ref_block = TRUE;
				distance_left_ref = msg->data[4] + 1;
			}
		}
		
		
		if (!neighbor_array[i]	){
			neighbor_array[i] = msg->data[1];
			
			//not supose to receive LEFT because it is the max right
			assert(msg->data[5] == LEFT);
			//if the ship go RIGHT chek if the BASE is at the left of the ship
			if (msg->data[0] == SHIP && (msg->data[4] < distance_left_ref && msg->data[5] == RIGHT)) {
				//set state to SHIP
				state = SHIP;
			}
			else if (msg->data[0] == METEORE){
			
				//ship explosion
				if (state == SHIP){
				
					state = EXPLOSION;
				}
				//if the state_send is ship and the state is VIDE then the meteore explode before the BASE so state is VIDE
				else if(state == VIDE && state_send == SHIP){
					state = VIDE;
				}
				else {
					// don't stop the game instantly because the ship could be arrive
					state = METEORE;
				}
			}
			break;
		}
		
	}
}


int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}
