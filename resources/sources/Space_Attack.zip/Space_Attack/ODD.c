#include <kilolib.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h> /* memset */


//state value
#define VIDE 0 // set_color (RGB(0,0,0));
#define METEORE 1 // set_color (RGB(2,1,0));
#define LASER 2 // set_color (RGB(3,3,0));
#define SHIP 3 // set_color (RGB(0,0,3));
#define EXPLOSION 4 // set_color (RGB(3,0,0));
#define GAME_OVER 5 // set_color (RGB(3,3,3));

//type value
#define GENERATOR 0
#define PAIR 1
#define ODD 2
#define BASE 3
#define BASE_CENTER 4 


#define FALSE 0
#define TRUE 1




int id;
int state;
int type;
int randomizer;
int distance_ship;
int neighbor_array [4];
int distance_block;
int state_send;


message_t message;
distance_measurement_t dist;







void setup() {


	//set the state
	state = VIDE;
	state_send = VIDE;
	id = kilo_uid;
	type = ODD;
	distance_ship = 0;
	distance_block = FALSE;


	//set the message to send
	message.type = NORMAL;
	message.data[0] = state_send;
	message.data[1] = id;
	message.data[2] = type;
	message.data[3] =  distance_ship;
	message.crc = message_crc(&message);

	//set the light
	set_color (RGB(0,0,0));



}

void loop() {
	if ( state == GAME_OVER){
		//game over
		set_color (RGB(3,3,3));
		state_send = GAME_OVER;
	}
	 if((kilo_ticks %64) == 0){ // start loop every 2 sec
		 if ( state == VIDE) {
			 state_send = VIDE;
			 set_color (RGB(0,0,0));
		 }
		 else if (state == METEORE){
			 state = VIDE;
			 set_color (RGB(2,1,0));
			 state_send = METEORE;
		 }
		 else if (state == EXPLOSION){
			 state = VIDE;
			 set_color (RGB(3,0,0));
			 state_send = EXPLOSION;
		 }
		 else if (state == LASER){
			 state = VIDE;
			 set_color (RGB(3,3,0));
			 state_send = LASER;
		 }
		 memset(neighbor_array,0,4 *sizeof(int));
	 }
}


//send a message
message_t* message_tx(){
	message.type = NORMAL;
	message.data[0] = state_send;
	message.data[1] = id;
	message.data[2] = type;
	message.data[3] =  distance_ship;
	message.crc = message_crc(&message);
	return &message;
}
// check a message
void message_rx(message_t *msg, distance_measurement_t *dist) {
	if (msg->data[0] == GAME_OVER){
		//stop the game if GAME_OVER
		state = GAME_OVER;
	}
	int i;
	for ( i = 0; i<4; i++) {

		//avoid that a kilobot could be count more than one time
		if(msg->data[1] == neighbor_array[i]){
			//stop loop if message already receive
			break;
			}
		if (!neighbor_array[i]	){
			
			neighbor_array[i] = msg->data[1];
			//setup  distance of the BASE
			if (distance_block == FALSE){
				if (msg->data[2] == BASE || msg->data[2] == BASE_CENTER || (msg->data[2] == ODD && msg->data[3] != 0) ){
					distance_block = TRUE;
					distance_ship = msg->data[3] + 1;
				}

			}

			if (msg->data[2] != PAIR){
				
				if (msg->data[0] == SHIP || (msg->data[0] == LASER && distance_ship > msg->data[3])) {
					if ( state == VIDE || state == EXPLOSION) {
						if (state_send == METEORE){
							state = EXPLOSION;
						}
						else{
							state = LASER;
						}
					}
					else if (state == METEORE){
						state = EXPLOSION;
					}
				}
				else if (msg->data[0] == METEORE && (distance_ship < msg->data[3] || msg->data[2] == GENERATOR )){
					
					if (state == LASER){
						if (state_send == LASER){
						}
						else {
						state = EXPLOSION;
						}
					}
					else if (state == VIDE || state == EXPLOSION) {
						if (state_send != LASER){
							state = METEORE;
						}
					}
				}
			}
			break;
			
		}
	}
}


int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}
