#include <kilolib.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h> /* memset */
#include <assert.h>

//state value
#define VIDE 0 // set_color (RGB(0,0,0));
#define METEORE 1 // set_color (RGB(2,1,0));
#define LASER 2 // set_color (RGB(3,3,0));
#define SHIP 3 // set_color (RGB(0,0,3));
#define EXPLOSION 4 // set_color (RGB(3,0,0));
#define GAME_OVER 5 // set_color (RGB(3,3,3));

//type value
#define GENERATOR 0
#define PAIR 1
#define ODD 2
#define BASE 3
#define BASE_CENTER 4






int id;
int state;
int state_send;
int type;
int randomizer;
int neighbor_array [3];


message_t message;
distance_measurement_t dist;







void setup() {


	//set the state
	state = VIDE;
	state_send = VIDE;
	id = kilo_uid;
	type = GENERATOR;


	//set the message to send
	message.type = NORMAL;
	message.data[0] = state_send;
	message.data[1] = id;
	message.data[2] = type;
	message.crc = message_crc(&message);

	//set the light
	set_color (RGB(0,0,0));



}

void loop() {
	if ( state == GAME_OVER){
		set_color (RGB(3,3,3));
		state_send = GAME_OVER;

	}
	else if((kilo_ticks %64) == 0){ // start loop every 2 sec

		 if ( state == VIDE || state == LASER) {
		 	 
			 randomizer = rand_hard() %5; // 0 or 1 or 2 or 3 or 4

			// meteore genereted
			 if (randomizer == 0){
			 	//make an explosion
				 if ( state == LASER){
					
					 state = VIDE;
				 	 set_color (RGB(3,0,0));
				 	 state_send = EXPLOSION;
				 }
				 //generate the meteore but don't send the information to wait on turn
				 else{
					 state = METEORE;
					 set_color (RGB(2,1,0));
					 state_send = VIDE;
				 }
			 }
			 else {
			 	// the laser is clear of the game
				 if (state == LASER){

				 	set_color (RGB(3,3,0));
				 }
				 // state VIDE	
				 else {

				 	set_color (RGB(0,0,0));

				 }
				 state = VIDE;
				 state_send = VIDE;
			 }
		 }
		 // clear the meteore and send the information
		 else if ( state == METEORE){

			 state = VIDE;
			 state_send = METEORE;
			 set_color (RGB(2,1,0));
			 
		 }
		 //clear the state of explosion
		 else if ( state == EXPLOSION){

			state = VIDE;
			set_color (RGB(3,0,0));
			state_send = EXPLOSION	;
		 }
		 //clear neighbor_array
		 memset(neighbor_array,0,1 * sizeof(int));
	 }
}


//send a message
message_t* message_tx(){
	message.type = NORMAL;
	message.data[0] = state_send;
	message.data[1] = id;
	message.data[2] = type;
	message.crc = message_crc(&message);
	return &message;
}
// check a message
void message_rx(message_t *msg, distance_measurement_t *dist) {
	if (msg->data[0] == GAME_OVER){
		//stop the game if GAME_OVER
		state = GAME_OVER;
	}


	int i;
	for ( i = 0; i<1; i++) {
		assert(i<1);
		//avoid that a cell could be count more than one time
		if(msg->data[1] == neighbor_array[i]){
			//stop loop if message already receive
			
			break;
			}
		if (!neighbor_array[i]	){
			// if the message is send by the kilobot under the GENERETOR
			if (msg->data[2] != GENERATOR){
				neighbor_array[i] = msg->data[1];
				
				if (msg->data[0]== LASER ){
					
					if(state == METEORE){ // explose meteore
						
						state = EXPLOSION;


					}
					// set state to explosion if state_send is METEORE because the meteore wait 2 turn in the GENERETOR
					else if(state_send == METEORE) {
						state = EXPLOSION;
									
					}
					else {
						state = LASER;
						
					}
				}
				break;
			}
			
		}
	}
}



int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}
