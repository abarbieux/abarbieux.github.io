#include <kilolib.h>
#include <stdlib.h>
#include <assert.h>

#define BALLE 0
#define HUNTER 1
#define LIMIT 2





message_t message;



void setup() {

	//set the message to send
	message.type = NORMAL;
	message.data[0] = LIMIT;
	message.crc = message_crc(&message);

	//set the light
	set_color (RGB(0,0,0));

}

void loop() {
}

//send message
message_t* message_tx(){
	return &message;
}
//check message
void message_rx(message_t *msg, distance_measurement_t *dist) {
}



int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}
