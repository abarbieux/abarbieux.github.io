#include <kilolib.h>
#include <stdlib.h>
#include <stdio.h>



#define BALLE 0
#define HUNTER 1
#define LIMIT 2

#define CATCH 0
#define WALL 1
#define RUN 2

#define READY 0
#define NOTREADY 1

int state;
int ready;
int catch_distance = 100;
int straightSpeedCalibrator = 1000; // Delay in milliseconds to go straight on 1cm (for irl kilobot)
int turningSpeedCalibrator = 2500; // Delay in milliseconds to make 1/2 turn around (for irl kilobot)
int Thedelay;
message_t message;



void setup() {
	//set de random seed
	rand_seed(100);
	//set the state
	state = RUN;
	ready = READY;	

	//set the message to send
	message.type = NORMAL;
	message.data[0] = BALLE;
	message.crc = message_crc(&message);

	//set the light and movement
	set_color (RGB(0,3,0)); //green
	
}

void loop() {
	
	if (state == RUN){
		// waiting  ball get away
		if (ready == NOTREADY) {
			set_motors(kilo_straight_left, kilo_straight_right);
			delay(straightSpeedCalibrator);
			ready = READY;
		}
		set_color (RGB(0,3,0)); //green
		// go straight
		spinup_motors();
		set_motors(kilo_straight_left, kilo_straight_right);

	}
	else if (state == CATCH) {
		//end the simulation, the ball is catch
		ready = NOTREADY;
		set_color (RGB(3,0,0)); // red
		set_motors(0,0);
	}
	// use to not apply a new message during the rotation

	else if (state == WALL){
		ready = NOTREADY;

		//choice a random direction in the circle
		int rotate = rand_soft() %501 ; //0 to 500
		
		int more_less = 0 ; //0 or 1
		
		
		//make a "+"
		if (more_less == 1){
			Thedelay = (turningSpeedCalibrator + rotate);
		}
		//make a "-"
		else{
			Thedelay = (turningSpeedCalibrator - rotate);
		}

		//change state to RUN again and turn the ball
		more_less = rand_soft() %2; //0 or 1
		
		spinup_motors();
		//turn right or left
		if (more_less == 1){
			set_motors(kilo_turn_left, 0);
		}
		else{
			set_motors(kilo_turn_right, 0);
		}
		delay(Thedelay);
		state = RUN;


	}
}
//send a message
message_t* message_tx(){
	return &message;
}
// check a message
void message_rx(message_t *msg, distance_measurement_t *dist) {
	if (estimate_distance(dist) < (catch_distance) ){

		if (msg->data[0] == HUNTER){
			state = CATCH;
		}
		else if (state == RUN && ready == READY) {
			if (msg->data[0] == LIMIT){
				state = WALL;
			}
		}	
	}
}



int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}
