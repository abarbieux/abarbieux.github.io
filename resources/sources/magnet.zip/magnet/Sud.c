#include <kilolib.h>
#include <stdlib.h>
#include <stdio.h>

#define SUD 0
#define NORD 1


#define STOP 0
#define FORWARD 1
#define LEFT 2
#define RIGHT 3

int dist_1 = 1000; // 1 cm
int dist_2 = 800; // 2 cm
int dist_3 = 500; // 3 cm
int dist_4 = 250; // 4 cm
int dist_5 = 100; // 5 cm
float power;


int type;
int state;
int minimal_distance = 10;
message_t message;
distance_measurement_t dist;

int old_distance;
int current_distance;
int new_message;





void set_motion(int new_motion){
	if (power != 0) {
		switch(new_motion){
		case STOP:
			set_motors(0,0);
			break;
		case FORWARD:
			spinup_motors();
			set_motors(255.0 * power,255.0 *power);
			break;
		case RIGHT:
			spinup_motors();
			set_motors(0,255.0 * power);
			break;
		case LEFT:
			spinup_motors();
			set_motors(255.0 * power,0);
			break;
		}
	}
}





void right(){
	set_motion(RIGHT);
	delay(500);
	set_motion(FORWARD);
	delay(100);
	set_motion(STOP);

}

void forward(){
	set_motion(FORWARD);
	delay(100);
	set_motion(STOP);


}

void left(){
	set_motion(LEFT);
	delay(500);//100 milli seconde
	set_motion(FORWARD);
	delay(100);
	set_motion(STOP);

}






void setup() {


	//set the state
	state = SUD;
	


	//set the message to send
	message.type = NORMAL;
	message.data[0] = state;
	message.crc = message_crc(&message);

	//set the light
	if (state == SUD){
		set_color (RGB(0,3,0));
	}
	else {
		set_color(RGB(3,0,0));
	}

	current_distance = 5;
	new_message = 0;
	old_distance= 5;
	power = 0 ;
	type = 5;



}

void loop() {
	//check if the current distance must be recalculated
	 if (new_message) {
		 new_message = 0;
	     //current_distance = estimate_distance(&message);
	 }



	 if (type == SUD){
		 //repel
		 if (state == SUD) {
			// turn right and go away
			if (current_distance < old_distance) {
				left();
				
			}
			// go away
			else if (current_distance == old_distance ){
				forward();
			}
			
			
			//turn left and go away
			else {
				right();
			}
			
		 }
		 
	 }
	 else if (type == NORD) {
		 
		 //attract
		 	 if (current_distance <= minimal_distance) {
			 	set_motion(STOP);
			 }
			 //turn right and go to the kilobot
			 else if (current_distance > old_distance) {
			 	 set_motion(LEFT);
			 	 delay(100);
			 	 set_motion(FORWARD);
				 delay(100);
				 set_motion(STOP);
			  }
			  //go to the kilobot
			  else if (current_distance == old_distance){
			 	 set_motion(FORWARD);
				 delay(100);
				 set_motion(STOP);
			  }
			  //turn right and go to the kilobot
			  else{
			 	 set_motion(RIGHT);
			 	 delay(100);
			 	 set_motion(FORWARD);
				 delay(100);
				 set_motion(STOP);
			  }
		  
	 }
	 type= 5 ;
}
//send a message
message_t* message_tx(){
	return &message;
}
// check a message
void message_rx(message_t *msg, distance_measurement_t *dist) {
	//change the polarity of kilobot
	
	new_message = 1;
	type = msg->data[0];
	current_distance = estimate_distance(dist);

	if(current_distance < dist_1){
		power = 1.0/5;
	}
	else if (current_distance >= dist_1 && current_distance < dist_2) {
		power = 2.0/5;
	}
	else if (current_distance >= dist_2 && current_distance < dist_3) {
		power = 3.0/5;
	}
	else if (current_distance >= dist_3 && current_distance < dist_4) {
		power = 4.0/5;
	}
	else if (current_distance >= dist_4 && current_distance < dist_5) {
		power = 1.0;
	}
	
}



int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}
