#include <kilolib.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h> /* memset */
#include <stdbool.h>

#define DEAD 0
#define LIVING 1


#define READY 1
#define NOTREADY 0





int state;
int neighbor_living;
int neighbor_dead;
int id;
int neighbor_array [20];
message_t message;

struct node {
	int key;
	struct node *next;

};

struct node *head = NULL;
struct node *current = NULL;



// to find the length of the list
int length() {
	int length =0;
	struct node *current;
	
	for ( current = head; current != NULL; current = current->next){
		length++;	
	 }
	
	return length;
}


//is list empty
bool isEmpty() {
   return head == NULL;
}

//find a link with given key
struct node* find(int key) {

   //start from the first link
   struct node* current = head;

   //if list is empty
   if(head == NULL) {
      return NULL;
   }

   //navigate through list
   while(current->key != key) {
	
      //if it is last node
      if(current->next == NULL) {
         return NULL;
      } else {
         //go to next link
         current = current->next;
      }
   }      
	
   //if data found, return the current Link
   return current;
}

//delete first item
struct node* deleteFirst() {

   //save reference to first link
   struct node *tempLink = head;
	
   //mark next to first link as first 
   head = head->next;
	
   //return the deleted link
   return tempLink;
}

//delete a link with given key
struct node* delete(int key) {

   //start from the first link
   struct node* current = head;
   struct node* previous = NULL;
	
   //if list is empty
   if(head == NULL) {
      return NULL;
   }

   //navigate through list
   while(current->key != key) {

      //if it is last node
      if(current->next == NULL) {
         return NULL;
      } else {
         //store reference to current link
         previous = current;
         //move to next link
         current = current->next;
      }
   }

   //found a match, update the link
   if(current == head) {
      //change first to point to next link
      head = head->next;
   } else {
      //bypass the current link
      previous->next = current->next;
   }    
	
   return current;
}

//insert link at the first location
void insertFirst(int key) {
   //create a link
   struct node *link = (struct node*) malloc(sizeof(struct node));
	
   link->key = key;
   
	
   //point it to old first node
   link->next = head;
	
   //point first to new first node
   head = link;
}



void setup() {

	//set state
	state = DEAD;
	neighbor_dead = 0;
	neighbor_living = 0;
	id = kilo_uid;

	//set the message to send
	message.type = NORMAL;
	message.data[0] = state;
	message.data[1] = id;
	message.crc = message_crc(&message);

	//set the light
	set_color (RGB(3,0,0)); //green
	
	
}

void loop() {

	if ((kilo_ticks %64) == 0){

		
		//check if I could be reanimated
		if(state == DEAD) {

			if(neighbor_living == 3) {
				state = LIVING;
				set_color (RGB(0,3,0)); //green
			}
		}
		//check if if the cellule must die
		else {

			if((neighbor_living != 2) && (neighbor_living != 3)) {

				state = DEAD;
				set_color (RGB(3,0,0)); //red
			}
		}
		//clear counter and array
		neighbor_living = 0;
		neighbor_dead = 0;
		
		while(!isEmpty()) {
			deleteFirst();
		}
	}

}

//send message
message_t* message_tx(){
	message.type = NORMAL;
	message.data[0] = state;
	message.data[1] = id;
	message.crc = message_crc(&message);
	return &message;
}
//check message
void message_rx(message_t *msg, distance_measurement_t *dist) {

	struct node *element = find(msg->data[1]);
	//check if the id wasn't already in the list
	if(!element){
	
		insertFirst(msg->data[1]);
		// add a dead cellule in the counter
		if(msg->data[0] == DEAD) {
			neighbor_dead += 1;
		}
		//add a living cellule in the counter
		else if(msg->data[0] == LIVING) {
			neighbor_living += 1;
		}	
	}

	
	

}

int main(){
	kilo_init();

	kilo_message_rx = message_rx;

	kilo_message_tx = message_tx;

	kilo_start(setup, loop);

	return 0;
}


